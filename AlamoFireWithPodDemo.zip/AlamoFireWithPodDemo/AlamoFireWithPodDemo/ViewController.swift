//
//  ViewController.swift
//  AlamoFireWithPodDemo
//
//  Created by CodeBetter on 18/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit
import Alamofire


class ViewController: UIViewController
{
    var postDic:[String:Any]=[:]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        request()
        getrequest()
    }
    
func request()
{
    print("--------------------------")
    postDic["email"]="b1@gmail.com"
    postDic["password"]="123"
    let urlString = "http://192.168.1.13:8080/RedDot/BloodBankLogin"
    
    Alamofire.request(urlString, method: .post, parameters: postDic, encoding: JSONEncoding.default, headers: ["Content-Type" : "application/json"]).responseJSON {
        response in
        switch response.result
        {
        case .success:
            print("post response----",response)
            break
        case .failure(let error):
            print("post erroe",error)
            
        }
    }
    }
    
    func getrequest()
    {
     
        postDic["email"]="b1@gmail.com"
        postDic["password"]="123"
        let urlString = "http://192.168.1.13:8080/RedDot/BloodBankLogin"
        
        Alamofire.request(urlString, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: ["Content-Type" : "application/json"]).responseJSON {
            response in
            switch response.result
            {
            case .success:
                print("get response---",response)
              
                break
            case .failure(let error):
                print("get error---",error)
                
            }
        }
        }


}

