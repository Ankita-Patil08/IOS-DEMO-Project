//
//  HomeViewController.swift
//  UserDefaultAndSegueDemo
//
//  Created by CodeBetter on 08/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController
{
    
    @IBOutlet weak var welcomeLabel: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool)
    {
        let userDef:UserDefaults = UserDefaults.standard
        let username:String? = userDef.value(forKey: "username") as? String
        if(username != nil)
        {
            welcomeLabel!.text = "welcome-\(username!)"
        }
    }
    
    

}
