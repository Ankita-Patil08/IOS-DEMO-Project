//
//  SignUpViewController.swift
//  UserDefaultAndSegueDemo
//
//  Created by CodeBetter on 08/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController
{
    
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var mobileField: UITextField!
    @IBOutlet weak var cityField: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func actionSubmit(_ sender: Any)
    {
        let uemail = emailField!.text
        let upass = passwordField!.text
        let umobile = mobileField!.text
        let ucity = cityField!.text
        
        let userdef:UserDefaults = UserDefaults.standard
        userdef.setValue(uemail, forKey: "useremail")
        userdef.setValue(upass, forKey: "userpass")
        userdef.setValue(umobile, forKey: "usermobile")
        userdef.setValue(ucity, forKey: "usercity")
        userdef.synchronize()
        self.dismiss(animated: true, completion: nil)
    }
    
    
}
