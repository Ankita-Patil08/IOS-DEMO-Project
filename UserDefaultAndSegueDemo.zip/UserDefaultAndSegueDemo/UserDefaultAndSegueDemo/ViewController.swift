//
//  ViewController.swift
//  UserDefaultAndSegueDemo
//
//  Created by CodeBetter on 08/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    
    @IBOutlet weak var emailField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func actionLogin(_ sender: Any)
    {
        print("action login")
    }
    //conditionaly launch sague
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool
    {
        let userdef:UserDefaults = UserDefaults.standard
        let uemail:String? = userdef.value(forKey: "useremail") as? String
        let upass:String? = userdef.value(forKey: "userpass") as? String
        
        print("segue",identifier)
        if(identifier == "segue_home")
        {
            if(emailField!.text! == uemail && passwordField!.text! == upass)
            {
                return true
            }
            else
            {
                return false
            }
        }
       return true
        
    }

    
    override func viewDidAppear(_ animated: Bool) {
        //open userDefault Dictionary
        let userDef: UserDefaults = UserDefaults.standard
     
        //get value of themecolor key
        let colorCode:Int? = userDef.value(forKey: "themecolor") as? Int
        if(colorCode != nil)
        {
            switch colorCode
            {
            case 0:
                self.view.backgroundColor = UIColor.red
            case 1:
                self.view.backgroundColor = UIColor.green
            case 2:
                self.view.backgroundColor = UIColor.blue
            case 3:
                self.view.backgroundColor = UIColor.yellow
            default:
                self.view.backgroundColor = UIColor.white
            }
        }
    }
}

