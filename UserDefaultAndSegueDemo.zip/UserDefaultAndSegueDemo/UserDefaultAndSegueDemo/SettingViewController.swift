//
//  SettingViewController.swift
//  UserDefaultAndSegueDemo
//
//  Created by CodeBetter on 08/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit

class SettingViewController: UIViewController

{
    
    @IBOutlet weak var nameField: UITextField!
    
    @IBOutlet weak var colorSegment: UISegmentedControl!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool)
    {
        let userdef:UserDefaults = UserDefaults.standard
        let colorCode:Int? = userdef.value(forKey: "themecolor") as? Int
        let username : String? = userdef.value(forKey: "username") as? String
        nameField!.text = username!
        colorSegment.selectedSegmentIndex = colorCode!
        
        
    }
    
    
    @IBAction func actionUpdate(_ sender: Any)
    {
        //save setting in user default
        let displayName = nameField!.text!
        let colorCode:Int = colorSegment!.selectedSegmentIndex
        
    //creating object of user default dictionaty
    //open user default dictionary
    let userdef:UserDefaults = UserDefaults.standard
    //add data
    userdef.setValue(displayName, forKey: "username")
    userdef.setValue(colorCode, forKey: "themecolor")
    //close dictionary
    userdef.synchronize()
    //close setting controller
    self.dismiss(animated: true, completion: nil)
        
   }
}
