//
//  ViewController.swift
//  ImagePicker
//
//  Created by CodeBetter on 23/10/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UIImagePickerControllerDelegate , UINavigationControllerDelegate
{

    @IBOutlet weak var myImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loadImage()
    }
    
    
    @IBAction func actioncamera(_ sender: Any)
    {
        
        
    }
    

    @IBAction func actiongallary(_ sender: Any)
    {
        let imagePickerCon = UIImagePickerController()
        imagePickerCon.sourceType = UIImagePickerController.SourceType.photoLibrary
    
    imagePickerCon.allowsEditing = true
    imagePickerCon.delegate = self
    self.present(imagePickerCon, animated: true, completion: nil)
        
        
    }
    
    //protocol methods-------------------
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        print("Received....", info)
        picker.dismiss(animated: true, completion: nil)
        
        
        //get selected images......
        let selectImage : UIImage = info[UIImagePickerController.InfoKey.editedImage] as! UIImage
        
        myImageView.image = selectImage
        
      //save selected image in document directory of your with the name profile.png
      //prepare path to save
      let pathArray : [String]   = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        
        print("All Path - ",pathArray)
        let docDirPath = pathArray[0]
        let filePath = docDirPath + "/profile.png"
    
        //save all bytes of selected Images at filePath
        let imageData : Data = selectImage.pngData()!
        let fm : FileManager = FileManager.default
        fm.createFile(atPath: filePath, contents: imageData, attributes: nil)
        print("saved...")
    }
    
    
   // function to load image
    func loadImage()
    {
    //prepare path to saved Image
    let pathArray : [String]   = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
            
            print("All Path - ",pathArray)
            let docDirPath = pathArray[0]
            let filePath = docDirPath + "/profile.png"
    
    //check if file exist
    let fm:FileManager = FileManager.default
    if( fm.fileExists(atPath : filePath) == true)
    {
        let savedImage:UIImage = UIImage(contentsOfFile: filePath)!
        myImageView.image = savedImage
    }
    
    
    }
}

