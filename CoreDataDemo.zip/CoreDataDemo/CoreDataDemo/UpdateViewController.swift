//
//  UpdateViewController.swift
//  CoreDataDemo
//
//  Created by CodeBetter on 19/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit
import CoreData

class UpdateViewController: UIViewController
{
    
    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var idField: UITextField!
    @IBOutlet weak var salaryField: UITextField!
    @IBOutlet weak var departmentField: UITextField!
    
    //var EmpTablViewRFVC:EmployeeListTableViewController?
    var getManObj:NSManagedObject?
    
    override func viewDidLoad() {
        super.viewDidLoad()
   nameField.text! = getManObj?.value(forKey: "name") as! String
   idField.text! = "\(getManObj?.value(forKey: "id") as! Int)"
   salaryField.text! = "\(getManObj?.value(forKey: "salary") as! Double)"
   departmentField.text! = "\(getManObj?.value(forKey: "department") as! String)"

    
        
    }
    
  @IBAction func actionBtnUpdate(_ sender: Any)
    {
        let name = nameField.text!
        let id = idField.text!
        let salary = salaryField.text!
        let depart = departmentField.text!
        
        if name.count > 0 && id.count > 0 && salary.count > 0 && depart.count > 0
                        {
               
                            getManObj!.setValue(name, forKey: "name")
                            getManObj!.setValue(Int(id)!, forKey: "id")
                            getManObj!.setValue(Double(salary)!, forKey: "salary")
                            getManObj!.setValue(depart, forKey: "department")
                            
                            //save data in ManagedContext
                            do{
                                try getContextObject().save()
                                print("Record:->",getManObj!)
                                print("Data Updated Successfully !!!!")
                            }
                            catch
                            {
                                print("Insert error:",error)
                            }
                        }
                        else
                        {
                            print("Please enter a required fields!!!")
                        }
                        
                self.navigationController?.popViewController(animated: true)
            }
        
        
        
        
    }
    

