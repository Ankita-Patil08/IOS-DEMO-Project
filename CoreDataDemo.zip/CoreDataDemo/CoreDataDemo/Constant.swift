//
//  Constant.swift
//  CoreDataDemo
//
//  Created by CodeBetter on 19/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import Foundation
import CoreData
import UIKit

func getContextObject() -> NSManagedObjectContext
{
    let appDel = UIApplication.shared.delegate as! AppDelegate
    return appDel.persistentContainer.viewContext
}
