//
//  ViewController.swift
//  CoreDataDemo
//
//  Created by CodeBetter on 19/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController
{
    
    
    
    @IBOutlet weak var txtFieldName: UITextField!
    
    @IBOutlet weak var textFieldId: UITextField!
    
    @IBOutlet weak var txtFieldSalary: UITextField!
    
    @IBOutlet weak var txtFieldDepartment: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func actionSave(_ sender: Any)
    {
        let name = txtFieldName.text!
        let id = textFieldId.text!
        let salary = txtFieldSalary.text!
        let depart = txtFieldDepartment.text!
        
       if name.count > 0 &&  id.count > 0 && salary.count > 0 && depart.count > 0
       {
        
        //prepare managed object to save data
    let newObj=NSEntityDescription.insertNewObject(forEntityName: "Employee", into: getContextObject())
        
        newObj.setValue(name, forKey: "name")
        newObj.setValue(Int(id)!, forKey: "id")
        newObj.setValue(Double(salary)!, forKey: "salary")
        newObj.setValue(depart, forKey: "department")
    
    //save data in ManagedContext
        do
        {
            try getContextObject().save()
            print("Record--",newObj)
            print("data saved Successfully...!!!")
        }
        catch
        {
            print("Insert error--",error)
        }
        
    }
       else
       {
        print("Please enter a required field")
        }
    }
    
}

