//
//  EmployeeListTableViewController.swift
//  CoreDataDemo
//
//  Created by CodeBetter on 19/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit
import CoreData

class EmployeeListTableViewController: UITableViewController

{    //data NSMAnagedObject me store ho rha h islie array bhi NSManagedObject ka banega
    var arrEmp:[NSManagedObject]=[]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //fetch request-----------
        //insme eek class hoti h NSFetchRequest ki iske liye pta hona chayea ki konsi entity sedata fetch ho rha h
        //fetchRequest generic type ka banega
        let fetch=NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        do
        {
            arrEmp=try getContextObject().fetch(fetch) as! [NSManagedObject]
            print("Employee Record-->",arrEmp)
            self.tableView.reloadData()
        }
        catch
        {
            print("Fetch error-->",arrEmp)
        }

    }
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return arrEmp.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        

    let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
    let manObj = arrEmp[indexPath.row]
        
    let name=manObj.value(forKey: "name") as! String
    let id = manObj.value(forKey: "id") as! Int
    let salary = manObj.value(forKey: "salary") as! Double
    let depart = manObj.value(forKey: "department") as! String
    
    cell.textLabel?.text = "Name-\(name)" + "ID-\(id)"
        cell.detailTextLabel?.text = "salary-\(salary)" + "Depart-\(depart)"
    
    cell.textLabel?.font = UIFont(name: "Arial", size: 22.0)
    cell.detailTextLabel?.font = UIFont(name: "Arial", size: 22.0)
    

        return cell
    }
    
    //delete func -----
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let delete = UIContextualAction(style: .destructive, title: "Delete")
        {
            (action,sourceView, completionHandler) in
            let manObj = self.arrEmp[indexPath.row]
            
            getContextObject().delete(manObj)
            do
            {
                try getContextObject().save()
                print("Deleted Successfully..!!")
            }
            catch{
                print("Delete error-->",error)
            }
            
            self.arrEmp.remove(at: indexPath.row)
            self.tableView.reloadData()
            completionHandler(true)
        }
        
     let swipeActionConfig = UISwipeActionsConfiguration(actions: [delete])
     swipeActionConfig.performsFirstActionWithFullSwipe = false
     return swipeActionConfig
    }
    
//----------didselect function---------------------
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     let upVC = self.storyboard?.instantiateViewController(identifier: "UpdateViewController") as! UpdateViewController
     upVC.getManObj = arrEmp[indexPath.row]
     self.navigationController?.pushViewController(upVC, animated: true)
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
