//
//  ViewController.swift
//  CollectionViewDemoProject
//
//  Created by CodeBetter on 04/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDataSource
{

    @IBOutlet weak var productCollectionView: UICollectionView!
    var productArray : [Product] = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
  let p1 = Product(title: "Shoes", price: 800, imagename: "Img1")
  let p2 = Product(title: "Book", price: 1000, imagename: "Img2")
  let p3 = Product(title: "Shirt", price: 750, imagename: "Img3")
  let p4 = Product(title: "Bag", price: 900, imagename: "Img4")
  let p5 = Product(title: "T-Shirt", price: 300, imagename: "Img5")

    productArray.append(p1)
    productArray.append(p2)
    productArray.append(p3)
    productArray.append(p4)
    productArray.append(p5)
        
//load cell xib design - nibfile is xibfile name
let cellNib:UINib = UINib(nibName: "ProductCollectionViewCell", bundle: nil)

//attach cell xib with collection view
productCollectionView.register(cellNib, forCellWithReuseIdentifier: "ProductCollectionViewCell")
        
productCollectionView.dataSource = self
        
}
    
    
    func numberOfSections(in collectionView: UICollectionView) -> Int
    {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return productArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell : ProductCollectionViewCell = productCollectionView.dequeueReusableCell(withReuseIdentifier: "ProductCollectionViewCell", for: indexPath) as! ProductCollectionViewCell
        
//show data of corresponding product on the cell
    let p = productArray[indexPath.row]
        cell.productImageView.image = UIImage(named: p.imagename)
        cell.priceLabel.text = "\(p.title)-\(p.price)"
   
        //cell k paas ek refrence esa h jo view controller or indexpath ko represent kr rha h
        cell.viewCon = self
        cell.indexPath = indexPath
        
        return cell;
    }


}

