//
//  ConfirmOrderViewController.swift
//  CollectionViewDemoProject
//
//  Created by CodeBetter on 04/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit

class ConfirmOrderViewController: UIViewController
{
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var titlePriceLabel: UILabel!
    @IBOutlet weak var quantityField: UITextField!
    
    //creating refrence of product class
    var   product : Product?
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imageView!.image = UIImage(named: product!.imagename)
        titlePriceLabel!.text = "\(product!.title) - \(product!.price)"
        
    }
    

    @IBAction func actionConfirm(_ sender: Any)
    {
        let alertCon :UIAlertController = UIAlertController(title: "-Order Information-", message: "Your order is Placed..!!", preferredStyle: UIAlertController.Style.alert)
        
        
    //add action buttons for cancel
    let actionCancel: UIAlertAction = UIAlertAction(title: "cancel", style: UIAlertAction.Style.cancel, handler: nil)
               
    //Add button to controller
    alertCon.addAction(actionCancel)
    self.present(alertCon, animated: true, completion: nil)
               
        
        
       // self.dismiss(animated: true, completion: nil)
        
    }
    
}
