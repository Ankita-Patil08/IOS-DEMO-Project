//
//  ProductCollectionViewCell.swift
//  CollectionViewDemoProject
//
//  Created by CodeBetter on 04/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.

//cell's class

import UIKit

class ProductCollectionViewCell: UICollectionViewCell
{
    
    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    
    //creating viewController and Indexpath class object
    var viewCon : ViewController?
    var indexPath : IndexPath?
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    @IBAction func actionAddToOrder(_ sender: Any)
    {
        //load next Controller
        let nextCon:ConfirmOrderViewController =  self.viewCon!.storyboard!.instantiateViewController(identifier: "ConfirmOrderViewController") as! ConfirmOrderViewController
        
        nextCon.product = viewCon!.productArray[indexPath!.row]
        self.viewCon!.present(nextCon, animated: true, completion: nil)
    }
    

}
