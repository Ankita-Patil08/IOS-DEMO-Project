//
//  Product.swift
//  CollectionViewDemoProject
//
//  Created by CodeBetter on 04/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import Foundation

class Product
{
    var title:String = ""
    var price : Float = 0
    var imagename : String = ""
    
    init()
    {
    
    }
    
    init(title:String,price:Float,imagename:String)
    {
        self.title = title
        self.price = price
        self.imagename = imagename
    }
}
