//
//  ViewController.swift
//  AlertControllerDemo
//
//  Created by CodeBetter on 24/10/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var field2: UITextField!
    @IBOutlet weak var field1: UITextField!
    
    @IBOutlet weak var DoSomethingbtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        DoSomethingbtn.layer.cornerRadius = 20
        
        
    }
    
    
    @IBAction func actionDoSomething(_ sender: Any)
    {
        let n1 : Int = Int(field1.text!)!
        let n2 : Int = Int(field2.text!)!
        
        print(n1 + n2)
        
        //prepare a alert
        let alertCon : UIAlertController = UIAlertController(title: "Do Something..", message: "Select Your Operation", preferredStyle: UIAlertController.Style.actionSheet)
        
        //add action buttons for sum
        let actionSum : UIAlertAction = UIAlertAction(title: "Sum", style: UIAlertAction.Style.default, handler: {
            
            (action:UIAlertAction?)->Void
            in
            let n3 = n1 + n2
            self.resultLabel!.text! = "Sum is : \(n3)"
        })
        
        alertCon.addAction(actionSum)
        
        
        //add action buttons for multiply
        let actionMultiply: UIAlertAction = UIAlertAction(title: "Multiply", style: UIAlertAction.Style.destructive, handler: {
            (action : UIAlertAction)->Void
                        in
                        let n4 = n1 * n2
                        self.resultLabel!.text = "Multiplication is = \(n4)"
                    })
            
            

                
        alertCon.addAction(actionMultiply)
        
        
        //add action buttons for cancel
        let actionCancel: UIAlertAction = UIAlertAction(title: "cancel", style: UIAlertAction.Style.cancel, handler: nil)
        
        //Add button to controller
        alertCon.addAction(actionCancel)
                        
                
    self.present(alertCon, animated: true, completion: nil)
        
        
        
    }
    

}

