//
//  ViewController.swift
//  GestureProgrammingDemo
//
//  Created by CodeBetter on 16/11/19.
//  Copyright © 2019 CodeBetter. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var imgView: UIImageView!
    var arrImages:[String] = []
    var count = 0
    
    @IBOutlet weak var nextLabel: UILabel!
    
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        arrImages = ["car1.png","car2.png","car3.png","car4.jpg","car5.png"]
        //enable swipe on imageView
     let gesture =   UISwipeGestureRecognizer(target: self, action: #selector(onSwipe))
        
    //swipe direction
        gesture.direction = UISwipeGestureRecognizer.Direction.left
        
    //attach gesture direction on image View
        gesture.direction = UISwipeGestureRecognizer.Direction.left
        imgView.addGestureRecognizer(gesture)
        imgView.isUserInteractionEnabled=true
        
        
    //add gesture on label
        let gesture2 =  UITapGestureRecognizer(target: self, action: #selector(onTap))
        nextLabel.addGestureRecognizer(gesture2)
        nextLabel.isUserInteractionEnabled = true
        
    }
    
   @objc func onTap()
   {
    let nVC=self.storyboard?.instantiateViewController(withIdentifier: "Next1ViewController") as! Next1ViewController
    self.present(nVC, animated: true, completion: nil)
    }
    
    
    
    
    
    
    
    @objc func onSwipe()
    {
        //display
        count = count+1
        if(count == arrImages.count)
        {
            count = 0
        }
    imgView.image = UIImage(named: arrImages[count])
        
    }


}

